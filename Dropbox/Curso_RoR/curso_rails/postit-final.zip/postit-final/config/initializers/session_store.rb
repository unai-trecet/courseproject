# Be sure to restart your server when you modify this file.

Postit::Application.config.session_store :cookie_store, key: '_postit-template_session'
